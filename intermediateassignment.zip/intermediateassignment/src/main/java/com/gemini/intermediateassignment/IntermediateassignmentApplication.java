package com.gemini.intermediateassignment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IntermediateassignmentApplication {

    public static void main(String[] args) {
        SpringApplication.run(IntermediateassignmentApplication.class, args);
    }

}