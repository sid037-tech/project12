package com.gemini.intermediateassignment.repository;

import com.gemini.intermediateassignment.modal.FileSystem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FileSystemRepository extends JpaRepository<FileSystem,Integer> {
    FileSystem findByFileName(String name);
}
