package com.gemini.intermediateassignment.service;

import com.gemini.intermediateassignment.modal.FileSystem;
import com.gemini.intermediateassignment.repository.FileSystemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FileSystemService {
    @Autowired
    FileSystemRepository fileSystemRepository;
    public FileSystem addFile(FileSystem fileSystem) {
        return fileSystemRepository.save(fileSystem);
    }

    public List<FileSystem> getFileList() {
        return fileSystemRepository.findAll();
    }

    public FileSystem findFileWithFileName(String name) {
        return fileSystemRepository.findByFileName(name);
    }

    public
      String deleteFile(String name) {
        int id=fileSystemRepository.findByFileName(name).getFileId();
        fileSystemRepository.deleteById(id);
        return "\"deleted\"";
    }
    public FileSystem editFile(FileSystem filesystem,String name) {
        FileSystem oldfile= fileSystemRepository.findByFileName(name);
        oldfile.setFileName(name);
        int id=oldfile.getFileId();
        oldfile.setFileId(id);
        oldfile.setCreatedDate(filesystem.getCreatedDate());
        oldfile.setContent(filesystem.getContent());
        oldfile.setFileType(filesystem.getFileType());
       fileSystemRepository.saveAndFlush(oldfile);
        return oldfile;
    }
}
