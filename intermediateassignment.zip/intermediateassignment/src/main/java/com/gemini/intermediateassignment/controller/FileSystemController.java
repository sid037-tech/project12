package com.gemini.intermediateassignment.controller;

import com.gemini.intermediateassignment.modal.FileSystem;
import com.gemini.intermediateassignment.service.FileSystemService;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@ApiModel
@RestController
public class FileSystemController {

    @Autowired
    FileSystemService fileSystemService;

    @ApiOperation(value = "Add file", notes="used to add new files",nickname = "enter file")
    @PostMapping("/file")
    @ResponseBody
    public FileSystem addFile(@RequestBody FileSystem fileSystem) {
        return fileSystemService.addFile(fileSystem);
    }

    @ApiOperation(value = "get files", notes="used to get all files",nickname = "get all files")
    @GetMapping("/file")
    public List<FileSystem> getAllFiles()
    {
        return fileSystemService.getFileList();
    }


    @ApiOperation(value = "get file of particular name", notes="used to get file of particular name")
    @GetMapping("/file/{fileName}")
    public FileSystem findByFileName(@PathVariable String fileName)
    {
        return  fileSystemService.findFileWithFileName(fileName);
    }


    @ApiOperation(value = "delete file", notes="used to delete file")
    @DeleteMapping("/file/{fileName}")
    public String deleteFile(@PathVariable String fileName)
    {
        return fileSystemService.deleteFile(fileName);
    }
    @ApiOperation(value = "update file", notes="used edit particular file",nickname = "edit file")
    @PutMapping("/file/{fileName}")
    public FileSystem editLeave(@RequestBody FileSystem fileSystem,@PathVariable String fileName) {
        return fileSystemService.editFile(fileSystem ,fileName);
    }

}
